const ipcRenderer = require('electron').ipcRenderer;
const config = require('../config.json')
const fetch = require('node-fetch')
const getId = (id) => document.getElementById(id)
var page = window.location.pathname.split("/").pop();
window.onload = () => { if (!page === "index.html") return; if ((config.token && config.type == "bot") && page == "index.html") { ipcRenderer.send('sendToken', config.token); console.log('token sent') } if ((config.token && config.type == "acc") && page == "index.html") { ipcRenderer.send('sendToken', config.token); console.log('account token sent') } }

const msg = document.getElementById('msg')
const token = () => { ipcRenderer.send("sendToken", getId("tokenInput").value); console.log(getId("tokenInput").value); localStorage.setItem('token', getId('tokenInput').value) }



ipcRenderer.on('msg', (event, data) => msg.innerText = data)
if (page === "takeover.html") getId("giveAdmin").addEventListener("click", function () { ipcRenderer.send('admin', getId('adminInput').value) })
if (page === "takeover.html") getId("changeVanity").addEventListener("click", function () { ipcRenderer.send('admin', getId('vanityInput').value) })
//getId("banAll").addEventListener("click", function() { ipcRenderer.send('banAll', true)})
if (page === "takeover.html") getId("submitGuildName").addEventListener("click", function () { ipcRenderer.send("changeGuildName", getId('guildNameInput').value) })
if (page === "takeover.html") getId("unbanUser").addEventListener("click", function () { ipcRenderer.send("unbanUser", getId('unbanId').value) })
if (page === "takeover.html") getId("submitGuildIcon").addEventListener("click", function () { ipcRenderer.send("changeGuildIcon", getId('guildIconInput').value) })
if (page === "takeover.html") getId("changeNicknames").addEventListener("click", function () { ipcRenderer.send("changeNicknames", getId('nickname').value) })
if (page === "takeover.html") getId("submitSpammer").addEventListener("click", function () { ipcRenderer.send("spammer", getId('spammerInput').value) })
if (page === "takeover.html") getId("botSettings").addEventListener("click", function () { ipcRenderer.send("openSettings", true) })
if (page === "takeover.html") getId("deleteAll").addEventListener("click", function () { ipcRenderer.send("deleteAll", true) })
if (page === "bot.html") getId("leaveServer").addEventListener("click", function () { ipcRenderer.send("leaveServer", getId('leaveServerId').value) })
if (page === "bot.html") getId("changeUsername").addEventListener("click", function () { ipcRenderer.send("changeUsername", getId('botUser').value) })
if (page === "takeover.html") getId("listInvites").addEventListener("click", function () { ipcRenderer.send('listInvites', true) })

if (page === "takeover.html") getId("spamChannels").addEventListener("click", function () { ipcRenderer.send('spamChannels', getId('channelName').value) })

getId("logOut").addEventListener("click", function () { ipcRenderer.send('logOut', true) })
getId("restart").addEventListener("click", function () { ipcRenderer.send('restart', true) })
ipcRenderer.on('resInvites', (event, data) => { let list = getId('invites'); data.forEach((item) => { let link = item.split(' ')[0]; let li = document.createElement("li"); li.innerHTML = `<a href="${link}">${item}</a>`; li.className = "liInvites"; list.appendChild(li); }); })
ipcRenderer.on('client', (event, data) => getId("header").innerHTML = getId("header").innerHTML + ` | ${data}`)
